import { notFound } from "next/navigation";


export const revalidate = 3600;

export async function generateStaticParams() {
  return [
    { id: "2024-01-01" },
    { id: "2024-01-02" },
    { id: "2024-01-03" },
  ];
}

export default async function ApodDetail({ params }) {
  const apiKey = process.env.NEXT_PUBLIC_NASA_API_KEY || "";

  const { id } = params;

  const apiUrl = `https://api.nasa.gov/planetary/apod?api_key=${apiKey}&date=${id}`;

  const res = await fetch(apiUrl, {
    cache: "force-cache",
  });


  if (!res.ok) {
    notFound();
  }

  const apodData = await res.json();

  return (
    <div className="box">
      {apodData.media_type === "image" ? (
        <figure className="image is-4by3">
          <img src={apodData.url} alt={apodData.title} />
        </figure>
      ) : (
        <div className="video-container">
          <iframe src={apodData.url} frameBorder="0" allowFullScreen></iframe>
        </div>
      )}
      <h2 className="title is-4">{apodData.title}</h2>
      <p>{apodData.explanation}</p>
    </div>
  );
}
